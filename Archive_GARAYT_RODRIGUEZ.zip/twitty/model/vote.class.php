<?php

class vote extends basemodel
{
	// Vide
}

?>
