<?php

class utilisateur extends basemodel
{
	// Vide
}

?>