<?php

class post extends basemodel
{
	// Vide
}

?>