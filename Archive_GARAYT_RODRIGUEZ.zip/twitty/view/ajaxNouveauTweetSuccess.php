<?php
	// RIEN. C'est le template qui se charge d'afficher le tweet.
	include($nameApp."/layout/tweet_template.php");
?>
