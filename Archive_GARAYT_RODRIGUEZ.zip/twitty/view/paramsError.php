<?php
    include("twitty/view/paramsSuccess.php");
?>
