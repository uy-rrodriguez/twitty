<?php // RIEN. C'est le layout qui se charge d'afficher les erreurs. ?>
