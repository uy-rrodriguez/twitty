<?php
    // C'est le layout qui se charge d'afficher les erreurs.
    
    include("inscriptionSuccess.php");
?>
