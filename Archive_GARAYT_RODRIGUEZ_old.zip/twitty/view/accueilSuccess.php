<h1>Actualité</h1>
<?php
    $tweet = array(
        "createur"=> "Don Omar",
        "image_profil"=> "profil.png",
        "prenom"=> "Prenom",
        "nom"=> "Nom",
        "message"=> "Ceci n'est pas un tweet.\n\tCelle ci est une nouvelle ligne de texte.",
        "image"=> "tweet_exemple.png",
        "date"=> "20/11/2015",
        "heure"=> "15:30",
        "votes"=> "10"
    );
    
	for($boucleTweet = 0 ; $boucleTweet < 10 ; $boucleTweet++) {
		include($nameApp."/layout/tweet_template.php");
	}
?>
